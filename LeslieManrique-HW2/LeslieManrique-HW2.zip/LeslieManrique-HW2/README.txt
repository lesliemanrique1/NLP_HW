
USAGE 
	
  INPUT_FILE OUTPUT_FILEaPattern Matching 
	
  Program1 -> dollars.py
		python dollars.py INPUT OUTPUT
		Description: 
    This is 1/2 program scripts for assignment 2.
    Identifies currency values from a given source file.
    Source file is identified by first command line argument. 
    Writes output to a separate file - expression matches dollars.txt
    Rewrites the original file to include brackets around expressions
    as indicated by second command line argument

 	Program2 -> phone.py
    python dollars.py INPUT  OUTPUT
    Description:
		This is 2/2 program scripts for assignment 2.
    Identifies phone numbersfrom a given source file.
    Source file is identified by first command line argument. 
    Writes output to a separate file - expression matches phone.txt
    Rewrites the original file to include brackets around expressions
    as indicated by second command line argument


INPUT FILE : test_dollar_phone_corpus.txt	
